<template>
  <div id="commodityClassification">
    <h1>商品分类</h1>
  </div>
</template>

<script>
export default {
  name: 'commodityClassification',
  data () {
    return {
      msg: ''
    }
  }
}
</script>
