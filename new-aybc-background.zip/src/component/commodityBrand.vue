<template>
  <div id="commodityBrand">
    <h1>商品品牌</h1>
  </div>
</template>

<script>
export default {
  name: 'commodityBrand',
  data () {
    return {
      msg: ''
    }
  }
}
</script>
