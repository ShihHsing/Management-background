<template>
  <div id="home">
  	<h1>首页</h1>
  </div>
</template>

<script>
export default {
  name: 'home',
  data () {
    return {
      msg: ''
    }
  }
}
</script>
